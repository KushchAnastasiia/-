from django.urls import reverse_lazy
from django.views import generic, View

from .models import Article
from .forms import ArticleForm


class ArticlesList(generic.ListView):
    model = Article
    context_object_name = 'articles'
    template_name = 'blog/main.html'


class ArticleCreate(generic.CreateView):
    form_class = ArticleForm
    template_name = 'blog/create.html'
    success_url = reverse_lazy('main')
